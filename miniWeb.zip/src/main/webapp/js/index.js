$(function(){
	$("#gomain").on("click", function(){
		location.href="./index.do";
	})	
});